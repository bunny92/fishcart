<?php

echo json_encode($product);